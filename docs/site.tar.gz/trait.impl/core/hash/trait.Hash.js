(function() {
    const implementors = Object.fromEntries([["llm_chain_bedrock",[["impl <a class=\"trait\" href=\"https://doc.rust-lang.org/1.97.1/core/hash/trait.Hash.html\" title=\"trait core::hash::Hash\">Hash</a> for <a class=\"struct\" href=\"llm_chain_bedrock/converse/struct.Model.html\" title=\"struct llm_chain_bedrock::converse::Model\">Model</a>",0]]],["llm_chain_ollama",[["impl <a class=\"trait\" href=\"https://doc.rust-lang.org/1.97.1/core/hash/trait.Hash.html\" title=\"trait core::hash::Hash\">Hash</a> for <a class=\"struct\" href=\"llm_chain_ollama/chat/struct.Model.html\" title=\"struct llm_chain_ollama::chat::Model\">Model</a>",0]]]]);
    if (window.register_implementors) {
        window.register_implementors(implementors);
    } else {
        window.pending_implementors = implementors;
    }
})()
//{"start":59,"fragment_lengths":[303,293]}