(function() {
    const implementors = Object.fromEntries([["llm_chain_anthropic",[["impl <a class=\"trait\" href=\"https://doc.rust-lang.org/1.97.1/core/str/traits/trait.FromStr.html\" title=\"trait core::str::traits::FromStr\">FromStr</a> for <a class=\"enum\" href=\"llm_chain_anthropic/messages/enum.Model.html\" title=\"enum llm_chain_anthropic::messages::Model\">Model</a>",0]]],["llm_chain_gemini",[["impl <a class=\"trait\" href=\"https://doc.rust-lang.org/1.97.1/core/str/traits/trait.FromStr.html\" title=\"trait core::str::traits::FromStr\">FromStr</a> for <a class=\"enum\" href=\"llm_chain_gemini/generate_content/enum.Model.html\" title=\"enum llm_chain_gemini::generate_content::Model\">Model</a>",0]]],["llm_chain_openai",[["impl <a class=\"trait\" href=\"https://doc.rust-lang.org/1.97.1/core/str/traits/trait.FromStr.html\" title=\"trait core::str::traits::FromStr\">FromStr</a> for <a class=\"enum\" href=\"llm_chain_openai/chat/enum.Model.html\" title=\"enum llm_chain_openai::chat::Model\">Model</a>",0]]]]);
    if (window.register_implementors) {
        window.register_implementors(implementors);
    } else {
        window.pending_implementors = implementors;
    }
})()
//{"start":59,"fragment_lengths":[325,333,309]}