(function() {
    const implementors = Object.fromEntries([["llm_chain",[["impl <a class=\"trait\" href=\"https://doc.rust-lang.org/1.97.1/core/iter/traits/collect/trait.FromIterator.html\" title=\"trait core::iter::traits::collect::FromIterator\">FromIterator</a>&lt;(<a class=\"struct\" href=\"https://doc.rust-lang.org/1.97.1/alloc/string/struct.String.html\" title=\"struct alloc::string::String\">String</a>, <a class=\"struct\" href=\"https://doc.rust-lang.org/1.97.1/alloc/string/struct.String.html\" title=\"struct alloc::string::String\">String</a>)&gt; for <a class=\"struct\" href=\"llm_chain/struct.Parameters.html\" title=\"struct llm_chain::Parameters\">Parameters</a>",0]]]]);
    if (window.register_implementors) {
        window.register_implementors(implementors);
    } else {
        window.pending_implementors = implementors;
    }
})()
//{"start":59,"fragment_lengths":[629]}