(function() {
    const implementors = Object.fromEntries([["llm_chain_openai",[["impl Config for <a class=\"struct\" href=\"llm_chain_openai/chat/struct.AzureV1Config.html\" title=\"struct llm_chain_openai::chat::AzureV1Config\">AzureV1Config</a>",0]]]]);
    if (window.register_implementors) {
        window.register_implementors(implementors);
    } else {
        window.pending_implementors = implementors;
    }
})()
//{"start":59,"fragment_lengths":[194]}